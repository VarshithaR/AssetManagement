package com.cg.asset.ui;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.asset.bean.AssetIMBean;
import com.cg.asset.bean.AssetInvBean;
import com.cg.asset.dao.AdminDAO;
import com.cg.asset.dao.IAdminDAO;
import com.cg.asset.exception.AdminException;
import com.cg.asset.exception.UserException;
import com.cg.asset.service.AdminService;
//import com.cg.asset.bean.UserAuthen;
import com.cg.asset.service.AuthenticateUserService;
import com.cg.asset.service.IAdminService;
import com.cg.asset.service.IAuthenticateUserService;
import com.cg.asset.service.IUserService;
import com.cg.asset.service.UserService;

public class User {
	static IAuthenticateUserService service=new AuthenticateUserService();
	static IAdminService service1=new AdminService();
	static IAdminService update=new AdminService();
	static int option=0;
	static int choice=0;
	static int flag=0;
	static int flag1=0;
    static String managerno="";
	public static void main(String[] args)throws AdminException, UserException {
		
		int a=0;
		Scanner scan=new Scanner(System.in);
        System.out.println("***********ASSET MANAGEMENT PORTAL*************");
        do{
        	
        	try
        	{
        	    a=0;
		        System.out.println("Please select the type of user");
		        System.out.println("1. Admin");
		        System.out.println("2. Manager");
		        // System.out.println("3. Exit");
		        option=scan.nextInt();
		        if(option<1 || option>2)
		        {
		        	System.err.println("Invalid option");
		        	System.out.println("Enter either 1 or 2 ");
		        	a=1;
		        }
		        
		        /*else if(option==3)
		        {
		        	System.out.println("Portal Terminated");
		        	System.exit(0);
		        }
		        */
		        else
		        {
		        		System.out.println("Enter your userid");
				        String user=scan.next();
				        System.out.println("Enter password");
				        String password=scan.next();
				        flag=service.authenticateUser(user,password,option);
				        if (flag==1)
				        {
				        	System.out.println("Logged in successfully as admin");
				        	
				        	
				        }
				        else if(flag==2)
				        {
				        	System.out.println("Logged in succesfully as Manager");
				        	managerno=user;
				        	managerMenu();
				        }
				
		        }
        	}
           catch(InputMismatchException e)
           {
                
         		 a=1;
         	     System.err.println("Check and re-enter the inputs");
         	    
           }
           catch(AdminException e)
           {
        	   	a=1;
	        	System.err.println(e);
	        	 
           }
        	System.err.flush();
        	scan.nextLine();
        	
     }while(a==1); 
   /* System.err.flush();
    	scan.nextLine();*/
//                                                ######################### A D M I N ############################     
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    	int z1=0;
    	if(flag==1)
        {
        	 do{
             	try{
                      z1=0;
            do{ 
            System.out.println("     ");
            System.out.println("ADMIN MENU");
        	System.out.println("1. Add a new asset");
        	System.out.println("2. Modify an asset");
        	System.out.println("3. Approve/Reject a request");
        	System.out.println("4. View list of assets based on allocated/unallocated assetsl");
        	System.out.println("4. Log Out");
        	System.out.println("5. Exit Portal");
        	choice=scan.nextInt();
            int a1=0;
            int d1=0;
            switch(choice)
            {
            case 1: {
            	   do{
            		   try{
		            	    a1=0;
		                    System.out.println("Enter a meaningful asset name");
		                    String du3=scan.nextLine();
		                    String aname=scan.nextLine();
		                    System.out.println("Enter a meaningful asset description");
		                    String adesc=scan.nextLine();
		                    System.out.println("Enter the asset quantity(in numbers)");
		                    int aquantity=scan.nextInt();
		                    String astatus="";
		                    int c=0;
		                    do{
		                    	try{
		                    		c=0;
                            System.out.println("Enter the status 1.Available \n 2.Not Available");
		                    int ch=scan.nextInt();
		                    
		                    switch(ch)
		                    {
		                    case 1:astatus="Available";
		                           break;
		                    case 2:astatus="Not Available";
		                           break;
		                    default:
		                    	    System.err.println("Invalid choice");
		                            System.out.println("Choose only 1 or 2");
		                            c=1;
		                            break;
		                    }
		                    	}
		                    	catch(InputMismatchException e)
		                    	{
		                    		System.err.println("Enter only 1 or 2");
		                    		c=1;
		                    	}
		                    	System.err.flush();
		                    	scan.nextLine();
		                    }while(c==1);
		                    AssetIMBean bean1=new AssetIMBean();
		                    bean1.setAssetName(aname);
		                    bean1.setAssetDesc(adesc);
		                    bean1.setAssetQuantity(aquantity);
		                    bean1.setAssetStatus(astatus);
                            // AssetIMBean bean1=new AssetIMBean(aid,aname,adesc,astatus);
		                    IAdminService service1=new AdminService();
		                    int inssuccess=service1.addAsset(bean1);
		                    if(inssuccess==1)
		                    {
		                    	System.out.println("Asset details inserted successfully");
		                    }
		                    else
		                    {
		                    	System.out.println("Asset insertion failed");
		                    }
		            }
            		   catch(InputMismatchException e){
	            		
	            		 a1=1;
	            	     System.err.println("Inputs not acceptable");
            		}
            		   catch(AdminException e)
            	  {
            		  System.err.println(e); 
            	  }
                  System.err.flush();
            	  scan.nextLine();  
            }while(a1==1);
            	  
                   break;
            }       
           
            case 2:
            	{    
            		System.out.println("Enter the asset ID you want to modify");
	            		int assetid1=scan.nextInt();
	            		int validId=service1.validateAssetId(assetid1);
	            		do{
	            			try{
	            				d1=0;
	            		if(assetid1==validId)
	            		{
                        
	            		System.out.println("Choose the asset parameter you want to modify");
            			System.out.println("1.AssetName \n 2.Asset Description \n 3.Asset Quantity \n 4.Asset Status\n 5.Navigate to main portal \n 6.Exit");
            		    int pchoice=scan.nextInt();
            		   
            		    
            			switch(pchoice)
            			{
            			case 1:
            					System.out.println("Enter the new asset name");
            			        String du2=scan.nextLine();
            			        String newaname=scan.nextLine();
            			        int updatedName=update.updateAssetName(validId,newaname);
            			        if(updatedName==1)
            			        {
            			        	System.out.println("Name of the asset updated to << "+newaname+" >>");
            			        }
            			        else
            			        {
            			        	System.out.println("Failed to update asset name");
            			        	
            			        }
            			        break;
            			     
            			case 2: 
            					System.out.println("Enter the new asset description");
            			        String du3=scan.nextLine();
		    			        String newadesc=scan.nextLine();
		    			        int updateddesc=update.updateAssetDesc(validId,newadesc);
		    			        if(updateddesc==1)
		    			        {
		    			        	System.out.println("Description of the Asset updated to << "+newadesc+" >>");
		    			        }
		    			        else
		    			        {
		    			        	System.out.println("Failed to update Asset Description");
		    			        	
		    			        }
		    			        break;
	
		            	case 3:
		            			System.out.println("Enter the new asset quantity");
		    			        int newaquant=scan.nextInt();
		    			        int updatedquant=update.updateQuantity(validId,newaquant);
		    			        if(updatedquant==1)
		    			        {
		    			        	System.out.println("Quantity of the Asset updated to << "+newaquant+" >>");
		    			        }
		    			        else
		    			        {
		    			        	System.out.println("Failed to update Asset Quantity");
		    			        }
		    			        break;
			
            			case 4:
	            				System.out.println("Choose the new asset status 1.Available    2.Not Available");
	            				int schoice=scan.nextInt();
	            				String newastatus="";
	            				switch(schoice)
	            				{
	            				case 1:newastatus="Available";
	            				       break;
	            				case 2:newastatus="Not Available";
	            				       break;
	            				default:System.out.println("Invalid choice");
	            				        break;
            				        
	            				}
	            				int updatedstatus=update.updateStatus(validId,newastatus);
		    			        if(updatedstatus==1)
		    			        {
		    			        	System.out.println("Status of the Asset updated to << "+newastatus+" >>");
		    			        }
		    			        else
		    			        {
		    			        	System.out.println("Failed to update Asset Status");
		    			        }
		    			        break;

            			case 5:	System.out.println("((Navigating to main menu))");
                        		System.out.println("-----------------------------");
                        		User.main(args);
                        		break;
            			case 6: System.out.println("Portal terminated");
                                System.exit(0);
                                break;
            			default:System.err.println("Invalid choice...Enter a number from 1 to 6 only");
            					d1=1;
            					
            				 	break;
            			        }
            			}
	
            			else{
            				System.out.println("Entered Asset Id is invalid");
            				d1=1;
            			}		
	            			
	            	}	catch(InputMismatchException e)
        				{
	            			d1=1;
        					System.err.println("enter only digits");
        					
        					
        				}	
	            			catch(AdminException e)
	            			{
	            				d1=1;
	            				System.err.println("Check the employee Id and try again");
	            				
	            			}
	                    	System.err.flush();
	                    	scan.nextLine();
	            		   }while(d1==1);

                     break;
                     
	         }
            
            case 3:
            {
 //*********
            	    System.out.println("Displaying the asset requests yet to be approved/rejected");
            		System.out.println(" ");
                    IAdminDAO serve=new AdminDAO();
                    ArrayList<AssetInvBean> displayPendingRequest=serve.displayAllocationEntries();
                    for(AssetInvBean disp:displayPendingRequest)
                    {
                    	System.out.println("Allocation ID: "+ disp.getAllocationid()+"  Asset ID: "+disp.getAssetid()+"  Emp no: "+disp.getEmpno()+"  Status: "+disp.getStatus());
                    	
                    }
                    int achoice=0;
	                do{
	                	
		            System.out.println("  ");	
		            System.out.println("Please select whether you want to approve or reject the request");
		            System.out.println("1. Approve       2.Reject");
		            achoice=scan.nextInt();
		            switch(achoice)
		            {
		            case 1: 
		            {
		            	System.out.println("Enter the Allocation Id for which the request needs to be approved:");
		            	int approveId=scan.nextInt();
		            	int checkedapproveId=serve.validateAllocationId(approveId);
		            	//System.out.println(checkedapproveId);
		            	if(checkedapproveId!=-1)
		            	{ 
		            		System.out.println("Checking whether the asset is available or not....");
		            		int assetexist=serve.checkAssetAvailabilty(approveId);
		            		System.out.println(assetexist);
		            		if(assetexist!=-1)
		            		{
		            		System.out.println("Are you sure you want to approve this request? 1.Yes\n 2.No");
		            		int confirm=scan.nextInt();
		            		switch(confirm)
		            		{
		            		case 1: int approve=serve.approveRequest(approveId);
				            		if(approve==1)
				            		{
				            		        System.out.println("<<Asset approved>>..Status changed to 'Allocated' ");
				            		        int recentid=serve.retrieveAssetId(approveId);
				            		        int changedquantity=serve.changeQuantity(recentid);
				            		        int newquantity=serve.getQuantity(recentid);
				            		        if(newquantity==0)
				            		        {
				            		        	int newstatus=serve.changeStatus(recentid);
				            		        }
				            		}
				            		else
				            		{
				            			System.out.println("Failed to approve request");
				            		}
				            		 break;
		            		case 2:  System.out.println("No changes to asset request");
		            		         break;
		            		default: System.out.println("Invalid option..Enter only 1 or 2");
		            		         break;
		            			
		            		}
			            		
			            }
		            	else
			            	{
			            		System.out.println("Unable to approve Asset as it is currently not available");
			            	}
		            }
			            else
			            {
			            		System.err.println("Invalid Allocation Id");
			            }
		            	
			            break;
		            }
		            case 2:	
		            	{
		            		System.out.println("Enter the Allocation Id for which the request needs to be rejected:");
		            		int rejectId=scan.nextInt();
			            	int checkedrejectId=serve.validateAllocationId(rejectId);
			            	if(checkedrejectId!=-1)
			            	{
			            		System.out.println("Are you sure you want to reject this request? 1.Yes\n 2.No");
			            		int confirm1=scan.nextInt();
			            		switch(confirm1)
			            		{
			            		case 1: int reject=serve.rejectRequest(rejectId);
					            		if(reject==1)
					            		{
					            		        System.out.println("<<Asset Rejected>>..Status changed to 'Rejected' ");
					            		}
					            		else
					            		{
					            			System.out.println("Failed to reject request");
					            		}
					            		break;
			            		case 2:  System.out.println("No changes to asset request");
			            				break;
			            		default: System.out.println("Invalid option..Enter only 1 or 2");
	            		        		 break;
			            		}
			            		
			            	}
			            	 else
					            {
					            		System.err.println("Invalid Allocation Id");
					            }
			            	break;
			              }
		            	default: System.out.println("Invalid option..Enter only 1 or 2");

		            }
	                }while(achoice > 2 || achoice< 1 );

		            break;
            }
            //*****************
            case 4: System.out.println("Logging Out..");
            		User.main(args);
			        break;   
            case 5: 
                    System.out.println("Portal terminated");
                    System.exit(0);
                    break;

           default: z1=1;
           			System.err.println("Enter the correct option number");  
           			break;
          }
            }while(choice!=4 ||choice!=5);

        	}
             	catch(InputMismatchException e)
        	{   
        		z1=1;
        		System.err.println("Check the type of input and try again");
        		
        	}
        	catch(AdminException e)
        	{	
        		z1=1;
        		System.err.println(e);
        		
        	}
             	System.err.flush();
        	scan.nextLine();
        }while(z1==1);
    }
	}
  //                                              ########################## M A N A G E R ########################  	   
 //-------------------------------------------------------------------------------------------------------------------------------------------------------------------   	   
      
    	public static void managerMenu() throws AdminException
    	{
    		int z2=0;  
    		Scanner scan=new Scanner(System.in); 
    	
        do
    {
    	try{
        	z2=0;
    	if(flag==2)
          
        { 
    		do{
    			
    			System.out.println("   ");
    			System.out.println("**********USER MENU********");
	    		System.out.println("Select one among the following options");
	        	System.out.println("1.Raise a request for an asset");
	        	System.out.println("2.View status of an asset request");
	        	System.out.println("3.Log Out");
	        	System.out.println("4.Exit");
	        	
	        	choice=scan.nextInt();
	        	int a1=0;
	        	int a3=0;
	        	switch(choice)
	        	{
	        	case 1: 
	        		{
        			IUserService service=new UserService();
        		    IUserService service1=new UserService();
        		    IUserService service2=new UserService();
        		    System.out.println("ASSET INVENTORY");
        		 
        	        ArrayList<AssetIMBean> displayInventory= service.displayAssetInventory();
        	       
        	        for(AssetIMBean disp:displayInventory)
        	        {
        	             System.out.println("Asset Id:" + disp.getAssetId()+" "+ "Asset Name:"+disp.getAssetName());
        	        }
        	        
        	        do{
                  	  	try{
	                  	  		a1=0;
				        	    System.out.println("Enter Employee number");
				        	    int eno=scan.nextInt();
				        	    int validateEmployee=service1.validateEmployee(eno);
				        	    //int validmanager=0;
				        	    if(validateEmployee!=-1)
				        	    {
				        	    int validmanager=service1.validateManager(eno,managerno);
				        	    if(validmanager==1)
				        	    {
				        	    System.out.println("Enter asset id with reference to the above displayed inventory");
				        	    int assetid=scan.nextInt();
				        	    int allocsuccess=service1.raiseAsset(eno,assetid);
					        	if(allocsuccess==1){
			        	        System.out.println("Request submitted successfully");
			        	        int reqidreturn=service2.returnReqid(assetid);
			        	        System.out.println("Your asset requisition Id is: "+ reqidreturn);
			        	        System.out.println("Please remember this for future reference");
}
					        	   else{
					        	    	 System.err.println("Request submission unsuccessful");
		        	        		}
        	        	
                  	  		    }
				        	    else
				        	    {
				        	    	System.err.println("Cannot submit request..Employee does not come under this manager");
				        	    	User.managerMenu();
				        	    	//User.main(args);
				        	    }
                  	  	}else
                  	  	{
                  	  		System.err.println("Employee does not exist");
                  	  		a1=1;
                  	  	}

                  	  	} catch(InputMismatchException e){
                  	    		a1=1;
		                  	    System.err.println("Check and re-enter the inputs");
                  	    }
                  	  	catch(UserException e)
                  	  	{
                  	  		System.err.println(e);
                  	  		a1=1;
                  	  	}
                  	  	System.err.flush();
                  	  scan.nextLine();
                  	  
                 }while(a1==1); 
        	break;
        	}
        	case 2: 
        	{   
        		do{
                      try{
        				    a3=0;
	        				System.out.println("Enter employee no.");
			        		int enumber=scan.nextInt();
			        		System.out.println("Enter the Asset requisition ID");
			        		int allocreqid=scan.nextInt();
			        		IUserService service3=new UserService();
			        		String reqstatus=service3.validateReqId(enumber,allocreqid);
			        		
			        		System.out.println("The status of asset requisition for the ID: "+allocreqid+" is "+"<<"+reqstatus+">>");
        			   }
        			
        			
        			catch(InputMismatchException e)
	        		{
	        				a3=1;
	        				System.err.println("Check and re-enter the inputs");
        			}
                      catch(UserException e)
          			{
  	        				a3=1;
  	        				System.err.println(e);
          			}
        			
        		    scan.nextLine();
        	}while(a3==1);
        			break;
      }
        	case 3: System.out.println("Logging out..");
        			User.main(null);
        	case 4: System.out.println("******Portal Terminated******");	
        	        System.exit(0);
        	
        	default: z2=1; 
        		     System.err.println("Enter the correct option number");
        	        
        	}
        }while(choice!=3 || choice!=4);
        }
    	
        }catch(InputMismatchException e)
    		{
        	z2=1;
        	System.err.println("Check the type of inputs.. enter numbers only");
    		}
    		
    		catch(UserException e)
    		{
    			z2=1;
    			System.err.println("Unable to process manager portal");
    		}
	
    	System.err.flush();
    	scan.nextLine();

   }while(z2==1);
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------

}

/*System.out.println("Please fill the asset requisition requirements");
System.out.println("Enter employee ID");
int eid=scan.nextInt();
System.out.println("Enter the Asset ID");
int assetId=scan.nextInt();
System.out.println("Enter the number of assets required");
int quantity=scan.nextInt();
IUserService user=new UserService();
flag1=user.raiseAsset(assetId,quantity);*/

