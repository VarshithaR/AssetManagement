package com.cg.asset.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.asset.bean.AssetIMBean;
import com.cg.asset.exception.UserException;

public class UserDAO implements IUserDAO {
	Connection conn=null;
	int insertsuccess=0;
	public int raiseAsset(int eno,int assetId)throws UserException {
       try {
			conn=DBUtil.establishConnection();
			PreparedStatement pstmt1=conn.prepareStatement(IQueryMapper.ALLOCINSERTQUERY);
			System.out.println("111111111111111111111111111");
			pstmt1.setInt(1,assetId);
			pstmt1.setInt(2,eno);
			System.out.println("111111111111111111111111111");
			insertsuccess=pstmt1.executeUpdate();
	        System.out.println(insertsuccess);
		 }
			catch (SQLException e) {
		   throw new UserException("Invalid details");
			
		}
		return insertsuccess;
	}

	
	/*@Override
	public int checkAsset() {
		// TODO Auto-generated method stub
		return 0;
	}
*/
	@Override
	public ArrayList<AssetIMBean> displayAssetInventory() throws UserException{
		ArrayList<AssetIMBean> displayInventory=new ArrayList();
		try {
			Connection conn=DBUtil.establishConnection();
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.DISPLAYINVQUERY);
	        ResultSet rs=pstmt.executeQuery();
	        while(rs.next())
	       {
	            int assetid=rs.getInt(1);
	            String assetname=rs.getString(2);
	            AssetIMBean display=new AssetIMBean();
	            display.setAssetId(assetid);
	            display.setAssetName(assetname);
	            displayInventory.add(display);
	       }
		
		
		
		
		} catch (SQLException e) {
		
			throw new UserException("Unable to display inventory at this moment");
		}
		catch(NullPointerException e){
		throw new UserException("Inventory is Empty");
		}
		return displayInventory;
	}


	@Override
	public int returnReqid(int assetid)throws UserException {
		int reqid=0;
		try{
		conn=DBUtil.establishConnection();
		PreparedStatement pstmt3=conn.prepareStatement(IQueryMapper.IDRETURNQUERY);
		pstmt3.setInt(1,assetid);
		ResultSet rs1=pstmt3.executeQuery();
		
		rs1.next();
		reqid=rs1.getInt(1);
		
		}
		catch (SQLException e) {
			throw new UserException("Asset ID is invalid");
			
		
		}
		catch(Exception e)
		{
			throw new UserException("Details entered are invalid");
		}
		return reqid;
	}


	@Override
	public String validateReqId(int enumber, int allocreqid) throws UserException {
		String status="";
		try{
			conn=DBUtil.establishConnection();
			PreparedStatement pstmt4=conn.prepareStatement(IQueryMapper.VALIDATERIDQUERY);
			pstmt4.setInt(1,allocreqid);
			pstmt4.setInt(2,enumber);
		    ResultSet rs1=pstmt4.executeQuery();
		    rs1.next();
		    int allocationid=rs1.getInt(1);
		    int employeenum=rs1.getInt(2);
		    if(allocationid==allocreqid && employeenum==enumber)
		    {
		    	PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.STATUSQUERY);
		    	pstmt.setInt(1, allocreqid);
		    	ResultSet rs=pstmt.executeQuery();
		    	rs.next();
		    	status=rs.getString(1);
		    }
		}  
		    catch (SQLException e) {
		       throw new UserException("Check EmployeeID and Request ID again");
		  
		}
		  catch(NullPointerException e)
		{
			  throw new UserException("No allocations exist");
		}
		catch(Exception e)
		{
			throw new UserException("Invalid request");
		}
	    //System.out.println("hhhhhhhh");
		return status;

	}
	@Override
	public int validateManager(int empno, String managerno) {
		Connection conn=null;
		int validation=0;;
		try {
			conn=DBUtil.establishConnection();
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.VALIDATEMANANGERQUERY);
			pstmt.setInt(1, empno);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
			{
				String managerno1=rs.getString(1);
			    if(managerno.equals(managerno1))
			{
				validation=1;
			}
			}
			else
			{
				validation=-1;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*if(rs.next())
		{
			 checkedAllocId=rs.getInt(1);
		}
		else{
			checkedAllocId=-1;
		}*/
		return validation;
	}


	@Override
	public int validateEmployee(int eno) {
		Connection conn=null;
		int validemp=0;
		try {
			conn=DBUtil.establishConnection();
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.VALIDATEEMPLOYEEQUERY);
			pstmt.setInt(1,eno);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
			{
				validemp=rs.getInt(1);
			}
			else
			{
				validemp=-1;
			}
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return validemp;
	}
}

















/*			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.EMPLOYEEQUERY);
pstmt.setInt(1,eno);
ResultSet rs=pstmt.executeQuery();
rs.next();
int empid=rs.getInt(1);
if(empid==eno)
{
	PreparedStatement pstmt1=conn.prepareStatement(IQueryMapper.ALLOCINSERTQUERY);
	pstmt1.setInt(1,assetId);
	pstmt1.setInt(2,eno);
	insertsuccess=pstmt1.executeUpdate();
/*}*/
/*else
{
	System.err.println("Employee ID is invalid");
}*/
