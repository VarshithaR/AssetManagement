package com.cg.asset.dao;

public interface IQueryMapper {
 public final static String LOGINQUERY="SELECT userid,userpassword,usertype from User_masters where userid=?  and userpassword=? and usertype=?";
 public final static String INSERTQUERY="INSERT into Asset values(genAssetID.nextval,?,?,?,?)";
 public final static String MODIFYQUERY="UPDATE Asset set assetname=?,assetdesc=?,quantity=?,status=? where assetid=?";
 public final static String DISPLAYINVQUERY="SELECT assetId, assetname from Asset";	
 public final static String EMPLOYEEQUERY="SELECT empno from Employees where empno=?";
 public final static String ALLOCINSERTQUERY="INSERT into Asset_Allocation values(reqid_seq.val,?,?,SYSDATE,null,'Pending')"; 
 public final static String IDRETURNQUERY="SELECT allocationid from Asset_Allocation where assetid=?";
 public final static String VALIDATERIDQUERY="SELECT allocationid,empno from Asset_Allocation where allocationid=? and empno=?";
 public final static String STATUSQUERY="SELECT request_status from Asset_Allocation where allocationid=?";
 public final static String VALIDATEASSETIDQUERY="SELECT assetId from Asset where assetId=?";
 public final static String UPDATENAMEQUERY="UPDATE Asset set assetname=? where assetid=?";
 public final static String UPDATEDESCQUERY="UPDATE Asset set assetdesc=? where assetid=?";
 public final static String UPDATEQUANTITYQUERY="UPDATE Asset set quantity=? where assetid=?";
 public final static String UPDATESTATUSQUERY="UPDATE Asset set status=? where assetid=?";
 public final static String DISPALLOCATIONQUERY="SELECT allocationid,assetid,empno,request_status from Asset_Allocation where request_status='Pending'";
 public final static String VALIDATEALLOCIDQUERY="SELECT allocationid from Asset_Allocation where allocationid=? and request_status='Pending'";
 public final static String APPROVEASSETQUERY="UPDATE Asset_Allocation set request_status='Allocated' where allocationid=?";
 public final static String REJECTASSETQUERY="UPDATE Asset_Allocation set request_status='Rejected' where allocationid=?";
 public final static String EXTRACTSTATUSQUERY="SELECT status from Asset where assetid=(SELECT assetid from Asset_Allocation where allocationid=?)";		
 public final static String GETASSETIDQUERY="SELECT assetid from Asset_Allocation where allocationid=?";
 public final static String CHANGEQUANTITYQUERY="UPDATE Asset set quantity=quantity-1 where assetid=?";
 public final static String GETQUANTITYQUERY="SELECT quantity from Asset where assetid=?";
 public final static String CHANGESTATUSQUERY="UPDATE Asset set status='Not Available' where assetid=?";
 public final static String VALIDATEMANANGERQUERY="SELECT mgrnumber from Employees where empno=?";
 public final static String VALIDATEEMPLOYEEQUERY="SELECT empno from Employees where empno=?";
 
 
 
 //update Asset set quantity=quantity-1 where asset_id=(select asset_id from asset_allocation where allocation_id=?)
}



