package com.cg.asset.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.asset.bean.AssetIMBean;
import com.cg.asset.bean.AssetInvBean;
import com.cg.asset.dao.DBUtil;
import com.cg.asset.dao.IQueryMapper;
import com.cg.asset.exception.AdminException;
import com.cg.asset.exception.UserException;


public class AdminDAO implements IAdminDAO {
	int insertsuccess=0;
	int modsuccess=0;
	@Override
	public int addAsset(AssetIMBean bean1) throws AdminException {
		Connection conn=null;
		try {
			conn=DBUtil.establishConnection();
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.INSERTQUERY);
			//pstmt.setInt(1,bean1.getAssetId());
			pstmt.setString(1, bean1.getAssetName());
			pstmt.setString(2, bean1.getAssetDesc());
            pstmt.setInt(3,bean1.getAssetQuantity());
            pstmt.setString(4,bean1.getAssetStatus());
            insertsuccess=pstmt.executeUpdate();
           // System.out.println(insertsuccess);
			
		} catch(SQLException e) {
			
			throw new AdminException("Unable to add new asset");
		}
		catch(NullPointerException e)
		{
			throw new AdminException("No table found");
		}
		catch(Exception e)
		{
			throw new AdminException("Failed to insert asset");
		}
	    return insertsuccess;
	}
	@Override
	public int validateAssetId(int assetId) throws AdminException {
		Connection conn=null;
		int checkedId=0;
		try{
			conn=DBUtil.establishConnection();
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.VALIDATEASSETIDQUERY);
			pstmt.setInt(1,assetId);
			ResultSet rs=pstmt.executeQuery();
			rs.next();
			int checkId=rs.getInt(1);
		
			if(checkId==assetId)
			{
			     checkedId=checkId;
			}
			else
			{
				checkedId=0;
			}
		}
		catch(SQLException e)
		{
			throw new AdminException("Unable to process the request");
		}
		catch(Exception e)
		{
			throw new AdminException("Check the details and try again");
		}
		return checkedId;

	}

	@Override
	public int modifyAsset(AssetIMBean bean2) {
		Connection conn=null;
		try {
			conn=DBUtil.establishConnection();
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.MODIFYQUERY);
			pstmt.setString(1, bean2.getAssetName());
			pstmt.setString(2, bean2.getAssetDesc());
            pstmt.setInt(3,bean2.getAssetQuantity());
            pstmt.setString(4,bean2.getAssetStatus());
            pstmt.setInt(5,bean2.getAssetId());
            modsuccess=pstmt.executeUpdate();
		    
		}
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		return modsuccess;
	}

	@Override
	public int displayAsset() {
		// TODO Auto-generated method stub
		return 0;
	}
    
	
	
	
	@Override
	public int updateAssetName(int assetId,String newname) throws AdminException {
		Connection conn=null;
		int updatesuccess1=0;
		
			try {
				conn=DBUtil.establishConnection();
			
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.UPDATENAMEQUERY);
			pstmt.setString(1,newname);
			pstmt.setInt(2, assetId);
			updatesuccess1=pstmt.executeUpdate();

			}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		return updatesuccess1;
	}
	
	
	@Override
	public int updateAssetDesc(int assetId,String newdesc) throws AdminException {
		Connection conn=null;
		int updatesuccess2=0;
		
			try {
				conn=DBUtil.establishConnection();
				PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.UPDATEDESCQUERY);
				pstmt.setString(1,newdesc);
				pstmt.setInt(2, assetId);
				updatesuccess2=pstmt.executeUpdate();
				}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		return updatesuccess2;
	}
	@Override
	public int updateQuantity(int assetId,int newquant) throws AdminException {
		Connection conn=null;
		int updatesuccess3=0;
		
			try {
				conn=DBUtil.establishConnection();
				PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.UPDATEQUANTITYQUERY);
				pstmt.setInt(1,newquant);
				pstmt.setInt(2, assetId);
				updatesuccess3=pstmt.executeUpdate();   
				}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		return updatesuccess3;
	}
	@Override
	public int updateStatus(int assetId,String newstatus) throws AdminException {
	
		
		        Connection conn=null;
		       int updatesuccess4=0;
		
			try {
				conn=DBUtil.establishConnection();
				PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.UPDATESTATUSQUERY);
				pstmt.setString(1,newstatus);
				pstmt.setInt(2, assetId);
				updatesuccess4=pstmt.executeUpdate();
				}
			
			
		
			catch (SQLException e) {
				throw new AdminException("");
				
			}

		return updatesuccess4;
	
		
		
		
		
	}
	@Override
	public ArrayList<AssetInvBean> displayAllocationEntries() throws AdminException {
		ArrayList<AssetInvBean> displayEntries=new ArrayList();
		try{
			Connection conn=DBUtil.establishConnection();
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.DISPALLOCATIONQUERY);
			ResultSet rs=pstmt.executeQuery();
	        while(rs.next())
	        {
	        	int allocid=rs.getInt(1);
	        	int assetid=rs.getInt(2);
	        	int emplno=rs.getInt(3);
	        	String status=rs.getString(4);
	        	AssetInvBean display=new AssetInvBean();
	        	display.setAllocationid(allocid);
	        	display.setAssetid(assetid);
	        	display.setEmpno(emplno);
	        	display.setStatus(status);
	        	displayEntries.add(display);

	        }
			
		} catch (SQLException e) {
		
			throw new AdminException("Unable to display asset entries at this moment");
		}
		
		catch(NullPointerException e){
			throw new AdminException("Unable to find entries");
			}
		
		
		return displayEntries;
	}
	
	@Override
	public int validateAllocationId(int allocId) throws AdminException {
		Connection conn=null;
		int checkedAllocId=0;
		try{
			conn=DBUtil.establishConnection();
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.VALIDATEALLOCIDQUERY);
			pstmt.setInt(1,allocId);
			ResultSet rs=pstmt.executeQuery();
			//int checkAllocId=0;
			if(rs.next())
			{
				 checkedAllocId=rs.getInt(1);
			}
			else{
				checkedAllocId=-1;
			}
			/*if(checkAllocId==allocId)
			{
			     checkedAllocId=checkAllocId;
			}
			else
			{
				checkedAllocId=0;
			}*/
		}catch(SQLException e)
		{
			System.out.println(e);
			//throw new AdminException("Unable to process the request");
		}
		catch(Exception e)
		{
			throw new AdminException("Check the details and try again");
		}
		return checkedAllocId;

		
		
	}
	@Override
	public int approveRequest(int approveId) {
		Connection conn=null;
		int approvesuccess=0;
		try {
			conn=DBUtil.establishConnection();
		
		PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.APPROVEASSETQUERY);
		pstmt.setInt(1, approveId);
		approvesuccess=pstmt.executeUpdate();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return approvesuccess;
	
	}
	
	@Override
	public int rejectRequest(int rejectId) {
		Connection conn=null;
		int rejectsuccess=0;
		try {
			conn=DBUtil.establishConnection();
		
		PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.REJECTASSETQUERY);
		pstmt.setInt(1, rejectId);
		rejectsuccess=pstmt.executeUpdate();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return rejectsuccess;

	}
	@Override
	public int checkAssetAvailabilty(int approveId) throws AdminException {
		Connection conn=null;
		int checkstatus=0;
		System.out.println("1111111");
		try{
			conn=DBUtil.establishConnection();
		PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.EXTRACTSTATUSQUERY);
		System.out.println("1111111");
		pstmt.setInt(1,approveId);
		ResultSet rs=pstmt.executeQuery();
		rs.next();
		
		String status=rs.getString(1);
		if(status.equals("Available"))
		{
			checkstatus=1;
		}
		else
		{
			checkstatus=-1;
		}
		
		
	}catch(SQLException e)
	{
		System.out.println(e);
		
	}
	catch(Exception e)
	{
		throw new AdminException("Check the details and try again");
	}
	return checkstatus;
	}
	
	
	
	@Override
	public int retrieveAssetId(int approveId) throws AdminException {
		Connection conn=null;
		 int retrievedId=0;
		try{
			conn=DBUtil.establishConnection();
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.GETASSETIDQUERY);
            pstmt.setInt(1,approveId);
           
            ResultSet rs=pstmt.executeQuery();
            if(rs.next())
			{
				 retrievedId=rs.getInt(1);
			}
            else{
            	retrievedId=-1;
            }
		}catch(SQLException e)
		{
			System.out.println(e);
			
		}
		catch(Exception e)
		{
			throw new AdminException("Check the details and try again");
		}
		return retrievedId;
}
	@Override
	public int changeQuantity(int assetid) throws AdminException {
		Connection conn=null;
		int changesuccess=0;
		try {
			conn=DBUtil.establishConnection();
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.CHANGEQUANTITYQUERY);
			pstmt.setInt(1, assetid);
			changesuccess=pstmt.executeUpdate();
			if(changesuccess==1)
			{
				PreparedStatement pstmt1=conn.prepareStatement(IQueryMapper.CHANGEQUANTITYQUERY);
				
			}
		}
		catch (SQLException e) {
			throw new AdminException("Unable to change quantity");
			
		}
		return changesuccess;
	}
	@Override
	public int getQuantity(int recentid) throws AdminException {
		
		Connection conn=null;
		 int retrievedquantity=0;
		try{
			conn=DBUtil.establishConnection();
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.GETQUANTITYQUERY);
           pstmt.setInt(1,recentid);
          
           ResultSet rs=pstmt.executeQuery();
           if(rs.next())
			{
        	   retrievedquantity=rs.getInt(1);
			}
           else{
        	   retrievedquantity=-1;
           }
		
		}catch(SQLException e)
		{
			System.out.println(e);
			//throw new AdminException("Unable to process the request");
		}
		catch(Exception e)
		{
			throw new AdminException("Check the details and try again");
		}
		return retrievedquantity;

	}
	@Override
	public int changeStatus(int recentid) throws AdminException {

        Connection conn=null;
       int changesuccess1=0;

   	try {
   		conn=DBUtil.establishConnection();
   		PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.CHANGESTATUSQUERY);
   		pstmt.setInt(2, recentid);
   		changesuccess1=pstmt.executeUpdate();
   	}
   	catch (SQLException e) {
		throw new AdminException("");
   	}
   	return changesuccess1;
     
	}
	
		
}
