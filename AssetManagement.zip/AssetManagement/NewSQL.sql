create table Asset(assetid number primary key,assetname varchar2(25),assetdesc varchar2(25),quantity number,status varchar2(15));
insert into ASSET values(101,'Laptop','HP laptop',10,'Available');
insert into ASSET values(102,'Desktop','HP Desktop',10,'Available');
drop table Asset;
select * from ASSET;
truncate table Asset;
create sequence genAssetID start with 100 increment by 1;
select * from user_masters;
SELECT userid,userpassword,usertype from User_masters where userid='155315' and userpassword='root' and usertype='Admin';
create table Department(dept_id int primary key,dept_name varchar2(50));
insert into Department values(dept_no_seq.nextval,'Learning and development');
create sequence dept_no_seq start with 10 increment by 10;
select * from Department;
insert into Department values(dept_no_seq.nextval,'Human Resources');
create table Employees(empno number(6) primary key,ename varchar2(25),job varchar2(50),mgrnumber number(10),hiredate date,dept_id number references Department(dept_id));
create sequence emp_num_seq start with 155100 increment by 1;
insert into Employees values(emp_num_seq.nextval,'Deepika','Trainer',null,'15-Sep-2014',10);
insert into Employees values(emp_num_seq.nextval,'Mandhara','HR',null,'20-Oct-2015',20);
insert into Employees values(emp_num_seq.nextval,'Lavanya','Analyst',155100,'25-Oct-2016',10);
insert into Employees values(emp_num_seq.nextval,'Vaibhavi','Analyst',155101,'18-Dec-2016',20);
select * from Employees;


create table Asset_allocation(allocationid number primary key,assetid number references Asset(assetid),empno number references Employees(empno),allocation_date date,releasedate date);
create sequence reqid_seq start with 500 increment by 1;
alter table Asset_allocation add quantity number(10);
select * from Asset_allocation;
select * from Employees;
INSERT into Asset_Allocation values(reqid_seq.nextval,101,155100,SYSDATE,SYSDATE+2,'Pending',5); 
alter table Asset_allocation add request_status varchar2(50);
select * from Asset_allocation;
INSERT into Asset_Allocation values(reqid_seq.nextval,101,155100,SYSDATE,SYSDATE+2,4,'available'); 
select * from asset;
alter table Asset_allocation delete quantity number(10);
delete quantity from Asset_allocation;
alter table Asset_allocation drop column quantity;
select * from Trainee_Details1;

SELECT status from Asset where assetid=(SELECT assetid from Asset_Allocation where allocationid=501);
select * from USER_MASTERS;
select * from EMPLOYEES;
truncate table EMPLOYEES;
truncate table Department;
insert into USER_MASTERS 
truncate table USER_MASTERS;
insert into USER_MASTERS values('155315','Varshitha','varshr','Admin');
insert into USER_MASTERS values('155250','Sushmitha','sush','Manager');
insert into USER_MASTERS values('155190','Sahana','sana','Manager');
insert into USER_MASTERS values('155300','Prerana','pr123','Manager');
insert into EMPLOYEES values(emp_num_seq.nextval,'Bhavya','HR',155300,'08-Feb-2014',20);
insert into EMPLOYEES values(emp_num_seq.nextval,'Ramya','HR',155190,'30-Jun-2014',20);


truncate table Asset_allocation;
truncate table Asset;
truncate table  EMPLOYEES;
drop table Asset_allocation;
drop table Asset;
drop table EMPLOYEES;

drop table DEPARTMENT;
drop table EMPLOYEE;

select * from USER_MASTERS;
create table Department(dept_id int primary key,dept_name varchar2(50));
select * from Department;
insert into Department values(10,'Learning and Development');
insert into Department values(20,'Human Resources');
insert into Department values(30,'Finance');

drop sequence emp_num_seq;

create sequence emp_num_seq start with 155100 increment by 1;

create table Employees(empno number(6) primary key,ename varchar2(25),job varchar2(50),mgrnumber varchar2(10),hiredate date,dept_id number references Department(dept_id));

insert into EMPLOYEES values(emp_num_seq.nextval,'Deepika','Trainer','155250','15-Nov-2014',10);
select * from EMPLOYEES;
insert into EMPLOYEES values(emp_num_seq.nextval,'Mandhara','Analyst','155190','20-Oct-2015',30);
insert into EMPLOYEES values(emp_num_seq.nextval,'Lavanya','Associate','155250','10-Jul-2013',30);
insert into EMPLOYEES values(emp_num_seq.nextval,'Vaibhavi','Trainee','155300','03-May-2018',10);
insert into EMPLOYEES values(emp_num_seq.nextval,'Bhavya','HR','155300','08-Feb-2014',20);
insert into EMPLOYEES values(emp_num_seq.nextval,'Ramya','HR','155190','30-Jun-2014',20);

drop sequence genAssetID;
create sequence genAssetID start with 100 increment by 1;

drop sequence reqid_seq;
create sequence reqid_seq start with 500 increment by 1;

